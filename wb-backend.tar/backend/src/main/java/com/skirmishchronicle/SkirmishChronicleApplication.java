package com.skirmishchronicle;

import com.skirmishchronicle.config.AppProperties;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
@EnableConfigurationProperties({AppProperties.class, com.skirmishchronicle.push.PushProperties.class})
public class SkirmishChronicleApplication {

    public static void main(String[] args) {
        SpringApplication.run(SkirmishChronicleApplication.class, args);
    }
}
